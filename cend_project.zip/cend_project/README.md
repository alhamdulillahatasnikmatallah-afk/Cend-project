# Cend Project

Floating Assistant app (Flutter) – Android + iOS

## Cara pakai (paling gampang)

1. Download / clone repo ini
2. Pastikan Flutter sudah terinstall
3. Jalankan perintah ini di folder project:

```bash
flutter pub get
flutter run
```

## Build APK lewat GitHub Actions

1. Push semua file ke GitHub (branch `main`)
2. Tunggu GitHub Actions selesai
3. Download APK di tab **Actions → Artifacts → cend-project-apk**

## Fitur

- Glassmorphism panel (efek kaca)
- Logo pixel dolphin
- Threshold slider
- Support Admin (QRIS)
- Floating overlay (Android)
