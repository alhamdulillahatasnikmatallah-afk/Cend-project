import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';
import 'package:permission_handler/permission_handler.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const CendApp());
}

class CendApp extends StatelessWidget {
  const CendApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Cend Project',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF0B0B0F),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  bool isLoading = false;
  String status = "Balon belum aktif";

  Future<void> _tambahBalon() async {
    setState(() {
      isLoading = true;
      status = "Meminta izin...";
    });

    final statusPermission = await Permission.systemAlertWindow.request();

    if (!statusPermission.isGranted) {
      setState(() {
        isLoading = false;
        status = "Izin ditolak. Harus diizinkan dulu.";
      });
      return;
    }

    if (await FlutterOverlayWindow.isActive()) {
      setState(() {
        isLoading = false;
        status = "Balon sudah aktif di layar";
      });
      return;
    }

    await FlutterOverlayWindow.showOverlay(
      height: 80,
      width: 80,
      alignment: OverlayAlignment.centerRight,
      overlayTitle: "Cend Project",
      overlayContent: "Balon aktif",
      enableDrag: true,
      flag: OverlayFlag.defaultFlag,
      visibility: NotificationVisibility.visibilityPublic,
    );

    setState(() {
      isLoading = false;
      status = "Balon berhasil ditambahkan!";
    });
  }

  Future<void> _hapusBalon() async {
    if (await FlutterOverlayWindow.isActive()) {
      await FlutterOverlayWindow.closeOverlay();
      setState(() {
        status = "Balon dihapus";
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF0B0B0F), Color(0xFF16161F)],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(28),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 100,
                  height: 100,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFFFF6B00).withOpacity(0.4),
                        blurRadius: 24,
                      ),
                    ],
                  ),
                  child: ClipOval(
                    child: Image.asset(
                      'assets/logo.png',
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => const Icon(
                        Icons.smart_toy,
                        size: 50,
                        color: Color(0xFFFF6B00),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                Text(
                  'CEND PROJECT',
                  style: GoogleFonts.pressStart2p(
                    fontSize: 16,
                    color: const Color(0xFFFF6B00),
                  ),
                ),
                const SizedBox(height: 40),
                SizedBox(
                  width: double.infinity,
                  height: 56,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFFF6B00),
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                      ),
                    ),
                    onPressed: isLoading ? null : _tambahBalon,
                    child: isLoading
                        ? const SizedBox(
                            width: 24,
                            height: 24,
                            child: CircularProgressIndicator(
                              color: Colors.white,
                              strokeWidth: 2,
                            ),
                          )
                        : Text(
                            'TAMBAHKAN BALON DI LAYAR',
                            style: GoogleFonts.pressStart2p(fontSize: 10),
                            textAlign: TextAlign.center,
                          ),
                  ),
                ),
                const SizedBox(height: 16),
                SizedBox(
                  width: double.infinity,
                  height: 48,
                  child: OutlinedButton(
                    style: OutlinedButton.styleFrom(
                      side: BorderSide(color: Colors.white.withOpacity(0.2)),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                    ),
                    onPressed: _hapusBalon,
                    child: Text(
                      'HAPUS BALON',
                      style: GoogleFonts.pressStart2p(
                        fontSize: 9,
                        color: Colors.white70,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 30),
                Text(
                  status,
                  style: GoogleFonts.pressStart2p(
                    fontSize: 8,
                    color: Colors.white54,
                  ),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
