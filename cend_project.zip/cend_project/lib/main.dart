import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';
import 'package:permission_handler/permission_handler.dart';

// ====================== OVERLAY ENTRY POINT ======================
@pragma("vm:entry-point")
void overlayMain() {
  runApp(const MaterialApp(
    debugShowCheckedModeBanner: false,
    home: OverlayBubble(),
  ));
}

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const CendApp());
}

class CendApp extends StatelessWidget {
  const CendApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Cend Project',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF0B0B0F),
      ),
      home: const HomePage(),
    );
  }
}

// ====================== HOME PAGE ======================
class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  bool isLoading = false;
  bool showQR = false;
  String status = "Balon belum aktif";

  Future<void> _tambahBalon() async {
    setState(() {
      isLoading = true;
      status = "Meminta izin...";
    });

    final permission = await Permission.systemAlertWindow.request();

    if (!permission.isGranted) {
      setState(() {
        isLoading = false;
        status = "Izin ditolak. Kasih izin di Settings!";
      });
      return;
    }

    if (await FlutterOverlayWindow.isActive()) {
      setState(() {
        isLoading = false;
        status = "Balon sudah aktif di layar";
      });
      return;
    }

    await FlutterOverlayWindow.showOverlay(
      height: 90,
      width: 90,
      alignment: OverlayAlignment.centerRight,
      enableDrag: true,
      flag: OverlayFlag.defaultFlag,
      overlayTitle: "Cend Project",
      overlayContent: "Balon aktif",
      visibility: NotificationVisibility.visibilityPublic,
    );

    setState(() {
      isLoading = false;
      status = "Balon berhasil ditambahkan!";
    });
  }

  Future<void> _hapusBalon() async {
    await FlutterOverlayWindow.closeOverlay();
    setState(() {
      status = "Balon dihapus";
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF0B0B0F), Color(0xFF16161F)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(28),
            child: showQR ? _buildSupportAdmin() : _buildMainMenu(),
          ),
        ),
      ),
    );
  }

  Widget _buildMainMenu() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
          width: 100,
          height: 100,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                color: const Color(0xFFFF6B00).withOpacity(0.45),
                blurRadius: 25,
              ),
            ],
          ),
          child: ClipOval(
            child: Image.asset(
              'assets/logo.png',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) =>
                  const Icon(Icons.smart_toy, size: 50, color: Color(0xFFFF6B00)),
            ),
          ),
        ),
        const SizedBox(height: 20),
        Text(
          'CEND PROJECT',
          style: GoogleFonts.pressStart2p(
            fontSize: 16,
            color: const Color(0xFFFF6B00),
          ),
        ),
        const SizedBox(height: 40),

        // Tombol Tambah Balon
        SizedBox(
          width: double.infinity,
          height: 56,
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFFF6B00),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
            ),
            onPressed: isLoading ? null : _tambahBalon,
            child: isLoading
                ? const SizedBox(
                    width: 24,
                    height: 24,
                    child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                  )
                : Text(
                    'TAMBAHKAN BALON DI LAYAR',
                    style: GoogleFonts.pressStart2p(fontSize: 10, color: Colors.white),
                    textAlign: TextAlign.center,
                  ),
          ),
        ),
        const SizedBox(height: 14),

        // Tombol Hapus Balon
        SizedBox(
          width: double.infinity,
          height: 48,
          child: OutlinedButton(
            style: OutlinedButton.styleFrom(
              side: BorderSide(color: Colors.white.withOpacity(0.25)),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
              ),
            ),
            onPressed: _hapusBalon,
            child: Text(
              'HAPUS BALON',
              style: GoogleFonts.pressStart2p(fontSize: 9, color: Colors.white70),
            ),
          ),
        ),
        const SizedBox(height: 14),

        // Tombol Support Admin
        SizedBox(
          width: double.infinity,
          height: 48,
          child: OutlinedButton(
            style: OutlinedButton.styleFrom(
              side: BorderSide(color: Colors.white.withOpacity(0.25)),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
              ),
            ),
            onPressed: () => setState(() => showQR = true),
            child: Text(
              'SUPPORT ADMIN',
              style: GoogleFonts.pressStart2p(fontSize: 9, color: Colors.white70),
            ),
          ),
        ),
        const SizedBox(height: 30),
        Text(
          status,
          style: GoogleFonts.pressStart2p(fontSize: 8, color: Colors.white54),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }

  Widget _buildSupportAdmin() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          'SUPPORT ADMIN',
          style: GoogleFonts.pressStart2p(
            fontSize: 14,
            color: const Color(0xFFFF6B00),
          ),
        ),
        const SizedBox(height: 8),
        Text(
          'Terima kasih sudah berusaha',
          style: GoogleFonts.pressStart2p(
            fontSize: 7,
            color: Colors.white54,
          ),
        ),
        const SizedBox(height: 24),
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
          ),
          child: Image.asset(
            'assets/qris.png',
            width: 220,
            errorBuilder: (_, __, ___) => const SizedBox(
              height: 220,
              child: Center(child: Text('QRIS tidak ditemukan', style: TextStyle(color: Colors.black))),
            ),
          ),
        ),
        const SizedBox(height: 28),
        SizedBox(
          width: double.infinity,
          height: 48,
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.white12,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
              ),
            ),
            onPressed: () => setState(() => showQR = false),
            child: Text(
              'KEMBALI',
              style: GoogleFonts.pressStart2p(fontSize: 10, color: Colors.white),
            ),
          ),
        ),
      ],
    );
  }
}

// ====================== BALON OVERLAY ======================
class OverlayBubble extends StatefulWidget {
  const OverlayBubble({super.key});

  @override
  State<OverlayBubble> createState() => _OverlayBubbleState();
}

class _OverlayBubbleState extends State<OverlayBubble> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;
  int clickCount = 0;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 150),
    );
    _scaleAnimation = Tween<double>(begin: 1.0, end: 0.75).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _onTap() async {
    SystemSound.play(SystemSoundType.click);
    await _controller.forward();
    await _controller.reverse();
    setState(() {
      clickCount++;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: Center(
        child: GestureDetector(
          onTap: _onTap,
          child: ScaleTransition(
            scale: _scaleAnimation,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 70,
                  height: 70,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFFFF6B00).withOpacity(0.7),
                        blurRadius: 14,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                  child: ClipOval(
                    child: Image.asset(
                      'assets/logo.png',
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => Container(
                        color: const Color(0xFFFF6B00),
                        child: const Icon(Icons.smart_toy, color: Colors.white, size: 36),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 6),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.7),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(
                    'You have $clickCount times',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
