import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';
import 'package:permission_handler/permission_handler.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const CendApp());
}

class CendApp extends StatelessWidget {
  const CendApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Cend Project',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF0B0B0F),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  double threshold = 70;
  bool isRunning = false;
  bool showQR = false;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      threshold = prefs.getDouble('threshold') ?? 70;
      isRunning = prefs.getBool('isRunning') ?? false;
    });
  }

  Future<void> _saveSettings() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble('threshold', threshold);
    await prefs.setBool('isRunning', isRunning);
  }

  Future<void> _startOverlay() async {
    final status = await Permission.systemAlertWindow.request();
    if (!status.isGranted) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Izin overlay dibutuhkan (Android)')),
        );
      }
      return;
    }

    if (await FlutterOverlayWindow.isActive()) return;

    await FlutterOverlayWindow.showOverlay(
      height: 120,
      width: 120,
      alignment: OverlayAlignment.centerRight,
      overlayTitle: "Cend Project",
      overlayContent: "Floating Bot aktif",
      enableDrag: true,
      flag: OverlayFlag.defaultFlag,
    );
  }

  Future<void> _stopOverlay() async {
    if (await FlutterOverlayWindow.isActive()) {
      await FlutterOverlayWindow.closeOverlay();
    }
  }

  void _toggleBot() async {
    setState(() => isRunning = !isRunning);
    await _saveSettings();

    if (isRunning) {
      await _startOverlay();
    } else {
      await _stopOverlay();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF0B0B0F), Color(0xFF16161F)],
          ),
        ),
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: showQR ? _buildQRIS() : _buildMainPanel(),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildMainPanel() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(28),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(28),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.07),
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: Colors.white.withOpacity(0.12)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 90,
                height: 90,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFFFF6B00).withOpacity(0.45),
                      blurRadius: 24,
                      spreadRadius: 2,
                    ),
                  ],
                ),
                child: ClipOval(
                  child: Image.asset('assets/logo.png', fit: BoxFit.cover),
                ),
              ),
              const SizedBox(height: 18),
              Text(
                'CEND PROJECT',
                style: GoogleFonts.pressStart2p(
                  fontSize: 16,
                  color: const Color(0xFFFF6B00),
                  letterSpacing: 1.5,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                'Floating Assistant',
                style: GoogleFonts.pressStart2p(
                  fontSize: 8,
                  color: Colors.white54,
                ),
              ),
              const SizedBox(height: 32),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'THRESHOLD',
                    style: GoogleFonts.pressStart2p(
                      fontSize: 9,
                      color: Colors.white70,
                    ),
                  ),
                  Text(
                    '${threshold.toInt()}%',
                    style: GoogleFonts.pressStart2p(
                      fontSize: 12,
                      color: const Color(0xFFFF6B00),
                    ),
                  ),
                ],
              ),
              SliderTheme(
                data: SliderThemeData(
                  activeTrackColor: const Color(0xFFFF6B00),
                  inactiveTrackColor: Colors.white12,
                  thumbColor: const Color(0xFFFF6B00),
                  overlayColor: const Color(0xFFFF6B00).withOpacity(0.2),
                ),
                child: Slider(
                  value: threshold,
                  min: 50,
                  max: 95,
                  divisions: 9,
                  onChanged: (v) {
                    setState(() => threshold = v);
                    _saveSettings();
                  },
                ),
              ),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                height: 54,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: isRunning
                        ? Colors.redAccent.withOpacity(0.9)
                        : const Color(0xFFFF6B00),
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                    elevation: 0,
                  ),
                  onPressed: _toggleBot,
                  child: Text(
                    isRunning ? 'STOP BOT' : 'START BOT',
                    style: GoogleFonts.pressStart2p(fontSize: 11),
                  ),
                ),
              ),
              const SizedBox(height: 14),
              SizedBox(
                width: double.infinity,
                height: 48,
                child: OutlinedButton(
                  style: OutlinedButton.styleFrom(
                    side: BorderSide(color: Colors.white.withOpacity(0.2)),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                  onPressed: () => setState(() => showQR = true),
                  child: Text(
                    'SUPPORT ADMIN',
                    style: GoogleFonts.pressStart2p(
                      fontSize: 9,
                      color: Colors.white70,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Text(
                isRunning ? '● BOT ACTIVE' : '○ BOT STANDBY',
                style: GoogleFonts.pressStart2p(
                  fontSize: 8,
                  color: isRunning ? Colors.greenAccent : Colors.white38,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildQRIS() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(28),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(28),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.07),
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: Colors.white.withOpacity(0.12)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'SUPPORT ADMIN',
                style: GoogleFonts.pressStart2p(
                  fontSize: 12,
                  color: const Color(0xFFFF6B00),
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Terima kasih sudah berusaha',
                style: GoogleFonts.pressStart2p(
                  fontSize: 7,
                  color: Colors.white54,
                ),
              ),
              const SizedBox(height: 24),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Image.asset('assets/qris.png', width: 220),
              ),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                height: 48,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white12,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                  onPressed: () => setState(() => showQR = false),
                  child: Text(
                    'KEMBALI',
                    style: GoogleFonts.pressStart2p(fontSize: 10),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
